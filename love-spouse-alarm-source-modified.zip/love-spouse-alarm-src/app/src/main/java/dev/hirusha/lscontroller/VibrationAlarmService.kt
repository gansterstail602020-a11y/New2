// SPDX-FileCopyrightText: 2026 Hirusha Adikari
// SPDX-License-Identifier: MIT
package dev.hirusha.lscontroller

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

class VibrationAlarmService : Service() {
    companion object {
        const val EXTRA_DURATION = "duration_seconds"
        const val EXTRA_MODE = "vibration_mode"
        private const val CHANNEL_ID = "vibration_alarm_channel"
        private const val NOTIFICATION_ID = 4109
    }

    private val handler = Handler(Looper.getMainLooper())
    private var ble: BleController? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, notification("Будильник вибрации запущен"))
        ble = BleController(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val duration = (intent?.getIntExtra(EXTRA_DURATION, 60) ?: 60).coerceIn(5, 600)
        val controller = ble ?: return START_NOT_STICKY
        val mode = (intent?.getIntExtra(EXTRA_MODE, 1) ?: 1).coerceIn(1, 9)
        controller.startCycle(mode) { status ->
            if (status.failed) stopSelf()
        }
        handler.removeCallbacksAndMessages(null)
        handler.postDelayed({
            // Send STOP for a short interval, then stop advertising completely.
            controller.stopAll()
            controller.startCycle(Protocol.Command.STOP.byte) { status ->
                if (status.failed) stopSelf()
            }
            handler.postDelayed({ stopSelf() }, 1800)
        }, duration * 1000L)
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        ble?.close()
        ble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Будильник вибрации", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Love Spouse Controller")
            .setContentText(message)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .build()
}
