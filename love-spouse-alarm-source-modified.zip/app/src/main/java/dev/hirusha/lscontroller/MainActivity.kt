// SPDX-FileCopyrightText: 2026 Hirusha Adikari
// SPDX-License-Identifier: MIT

package dev.hirusha.lscontroller

import android.Manifest
import android.content.pm.PackageManager
import android.app.TimePickerDialog
import android.app.AlarmManager
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.selected
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

class MainActivity : ComponentActivity() {

    private lateinit var ble: BleController
    private var hasBluetoothPermission by mutableStateOf(false)

    private val permLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> hasBluetoothPermission = granted }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        ble = BleController(this)
        hasBluetoothPermission = ble.hasPermission

        if (Build.VERSION.SDK_INT >= 31 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_ADVERTISE)
            != PackageManager.PERMISSION_GRANTED
        ) {
            permLauncher.launch(Manifest.permission.BLUETOOTH_ADVERTISE)
        }

        setContent {
            val dark = isSystemInDarkTheme()
            val colors = when {
                Build.VERSION.SDK_INT >= 31 && dark -> dynamicDarkColorScheme(this)
                Build.VERSION.SDK_INT >= 31 -> dynamicLightColorScheme(this)
                dark -> darkColorScheme()
                else -> lightColorScheme()
            }
            MaterialTheme(colorScheme = colors) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    ControllerScreen(ble, hasBluetoothPermission) {
                        if (Build.VERSION.SDK_INT >= 31) {
                            permLauncher.launch(Manifest.permission.BLUETOOTH_ADVERTISE)
                        }
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::ble.isInitialized) hasBluetoothPermission = ble.hasPermission
    }

    override fun onDestroy() {
        ble.close()
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ControllerScreen(
    ble: BleController,
    hasBluetoothPermission: Boolean,
    requestPermission: () -> Unit
) {
    val context = LocalContext.current
    val alarmPrefs = remember { AlarmScheduler.prefs(context) }
    var alarmEnabled by remember { mutableStateOf(alarmPrefs.getBoolean(AlarmScheduler.KEY_ENABLED, false)) }
    var alarmHour by remember { mutableIntStateOf(alarmPrefs.getInt(AlarmScheduler.KEY_HOUR, 7)) }
    var alarmMinute by remember { mutableIntStateOf(alarmPrefs.getInt(AlarmScheduler.KEY_MINUTE, 0)) }
    var alarmDuration by remember { mutableIntStateOf(alarmPrefs.getInt(AlarmScheduler.KEY_DURATION, 60)) }
    var alarmMode by remember { mutableIntStateOf(alarmPrefs.getInt(AlarmScheduler.KEY_MODE, 1)) }
    var durationMenuExpanded by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf(context.getString(R.string.idle)) }
    var activeCommand by remember { mutableStateOf<Protocol.Command?>(null) }
    var manualRandomRunning by remember { mutableStateOf(false) }
    var selectedPrefixIndex by remember { mutableIntStateOf(-1) }
    var prefixMenuExpanded by remember { mutableStateOf(false) }

    val prefixOptions = listOf(stringResource(R.string.all_prefixes)) +
        Protocol.PREFIXES.map { context.getString(R.string.prefix_option, it.name, it.deviceCount) }
    val selectedLabel = prefixOptions[selectedPrefixIndex + 1]
    val isActive = activeCommand != null

    LaunchedEffect(hasBluetoothPermission) {
        status = ble.unavailableReason() ?: context.getString(R.string.idle)
        if (!hasBluetoothPermission) {
            ble.stopAll()
            activeCommand = null
        }
    }

    fun send(cmd: Protocol.Command) {
        if (activeCommand == cmd) {
            ble.stopAll()
            activeCommand = null
            status = context.getString(R.string.stopped)
            return
        }
        activeCommand = cmd
        val updateStatus: (BroadcastStatus) -> Unit = { update ->
            status = update.text
            if (update.failed) activeCommand = null
        }
        if (selectedPrefixIndex == -1) {
            ble.startCycle(cmd.byte, onStatus = updateStatus)
        } else {
            val prefix = Protocol.PREFIXES[selectedPrefixIndex]
            ble.startSingle(prefix.bytes, cmd.byte, onStatus = updateStatus)
        }
    }

    fun stop() {
        ble.stopAll()
        activeCommand = null
        status = context.getString(R.string.stopped)
    }

    val fontScale = LocalDensity.current.fontScale
    BoxWithConstraints(Modifier.fillMaxSize().systemBarsPadding()) {
        val minimumHeight = 560.dp * fontScale + if (hasBluetoothPermission) 0.dp else 48.dp
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .heightIn(min = maxOf(maxHeight, minimumHeight))
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    stringResource(R.string.app_name),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
                StatusChip(
                    label = if (isActive) activeCommand!!.label(context) else stringResource(R.string.idle),
                    active = isActive
                )
            }

            ExposedDropdownMenuBox(
                expanded = prefixMenuExpanded,
                onExpandedChange = { prefixMenuExpanded = it }
            ) {
                OutlinedTextField(
                    value = selectedLabel,
                    onValueChange = {},
                    readOnly = true,
                    label = { Text(stringResource(R.string.prefix)) },
                    trailingIcon = {
                        ExposedDropdownMenuDefaults.TrailingIcon(prefixMenuExpanded)
                    },
                    modifier = Modifier
                        .menuAnchor()
                        .fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
                ExposedDropdownMenu(
                    expanded = prefixMenuExpanded,
                    onDismissRequest = { prefixMenuExpanded = false }
                ) {
                    prefixOptions.forEachIndexed { i, label ->
                        DropdownMenuItem(
                            text = { Text(label) },
                            onClick = {
                                selectedPrefixIndex = i - 1
                                prefixMenuExpanded = false
                            }
                        )
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Рандом — ручной запуск", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Рандом работает отдельно от будильника. «Рывок сейчас» быстро перебирает режимы и затем возвращает рандом, если он был запущен.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = {
                                if (manualRandomRunning) {
                                    context.startService(Intent(context, VibrationAlarmService::class.java).setAction(VibrationAlarmService.ACTION_STOP))
                                    manualRandomRunning = false
                                    activeCommand = null
                                    status = "Рандом остановлен"
                                } else {
                                    val intent = Intent(context, VibrationAlarmService::class.java)
                                        .putExtra(VibrationAlarmService.EXTRA_DURATION, 2400)
                                        .putExtra(VibrationAlarmService.EXTRA_MODE, 10)
                                    ContextCompat.startForegroundService(context, intent)
                                    manualRandomRunning = true
                                    status = "Ручной рандом запущен"
                                }
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text(if (manualRandomRunning) "■ Стоп" else "🎲 Рандом · 40 мин") }
                        OutlinedButton(
                            onClick = {
                                val intent = Intent(context, VibrationAlarmService::class.java).setAction(VibrationAlarmService.ACTION_BURST)
                                ContextCompat.startForegroundService(context, intent)
                                status = "⚡ Быстрый перебор режимов"
                            },
                            modifier = Modifier.weight(1f)
                        ) { Text("⚡ Рывок сейчас") }
                    }
                }
            }

            Spacer(Modifier.height(12.dp))
            Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Будильник вибрации", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        OutlinedButton(
                            onClick = {
                                TimePickerDialog(context, { _, h, m ->
                                    alarmHour = h; alarmMinute = m
                                    alarmPrefs.edit().putInt(AlarmScheduler.KEY_HOUR, h).putInt(AlarmScheduler.KEY_MINUTE, m).apply()
                                    if (alarmEnabled) AlarmScheduler.scheduleNext(context)
                                }, alarmHour, alarmMinute, true).show()
                            }, modifier = Modifier.weight(1f)
                        ) { Text("Время: %02d:%02d".format(alarmHour, alarmMinute)) }
                        Box(modifier = Modifier.weight(1f)) {
                            OutlinedButton(onClick = { durationMenuExpanded = true }, modifier = Modifier.fillMaxWidth()) {
                                Text("Длительность: " + when (alarmDuration) { 30 -> "30 сек"; 60 -> "1 мин"; 120 -> "2 мин"; 300 -> "5 мин"; 600 -> "10 мин"; 1200 -> "20 мин"; 2400 -> "40 мин"; else -> "${alarmDuration}с" })
                            }
                            DropdownMenu(expanded = durationMenuExpanded, onDismissRequest = { durationMenuExpanded = false }) {
                                listOf(30, 60, 120, 300, 600, 1200, 2400).forEach { seconds ->
                                    val durationLabel = when (seconds) { 30 -> "30 секунд"; 60 -> "1 минута"; 120 -> "2 минуты"; 300 -> "5 минут"; 600 -> "10 минут"; 1200 -> "20 минут"; 2400 -> "40 минут"; else -> "${seconds} секунд" }
                                    DropdownMenuItem(text = { Text(durationLabel) }, onClick = {
                                        alarmDuration = seconds
                                        alarmPrefs.edit().putInt(AlarmScheduler.KEY_DURATION, seconds).apply()
                                        durationMenuExpanded = false
                                    })
                                }
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(modifier = Modifier.weight(1f)) {
                            var alarmModeMenu by remember { mutableStateOf(false) }
                            OutlinedButton(onClick = { alarmModeMenu = true }, modifier = Modifier.fillMaxWidth()) {
                                Text("Режим: " + if (alarmMode == 10) "Рандом (9 режимов)" else alarmMode.toString())
                            }
                            DropdownMenu(expanded = alarmModeMenu, onDismissRequest = { alarmModeMenu = false }) {
                                (1..9).forEach { mode ->
                                    DropdownMenuItem(text = { Text("$mode — вибрация") }, onClick = {
                                        alarmMode = mode
                                        alarmPrefs.edit().putInt(AlarmScheduler.KEY_MODE, mode).apply()
                                        alarmModeMenu = false
                                    })
                                }
                            }
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = {
                            if (!alarmEnabled) {
                                val alarmManager = context.getSystemService(AlarmManager::class.java)
                                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !alarmManager.canScheduleExactAlarms()) {
                                    Toast.makeText(
                                        context,
                                        "Разреши точные будильники для LS Controller, затем нажми кнопку ещё раз.",
                                        Toast.LENGTH_LONG
                                    ).show()
                                    try {
                                        context.startActivity(
                                            Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                                                data = Uri.parse("package:${context.packageName}")
                                            }
                                        )
                                    } catch (_: Exception) {
                                        context.startActivity(
                                            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                                                data = Uri.parse("package:${context.packageName}")
                                            }
                                        )
                                    }
                                    return@Button
                                }
                                alarmEnabled = true
                                alarmPrefs.edit().putBoolean(AlarmScheduler.KEY_ENABLED, true).apply()
                                AlarmScheduler.scheduleNext(context)
                            } else {
                                alarmEnabled = false
                                alarmPrefs.edit().putBoolean(AlarmScheduler.KEY_ENABLED, false).apply()
                                AlarmScheduler.cancel(context)
                            }
                        }, modifier = Modifier.weight(1f)) {
                            Text(if (alarmEnabled) "Будильник включён" else "Включить ежедневно")
                        }
                        if (alarmEnabled) {
                            OutlinedButton(onClick = { alarmEnabled = false; alarmPrefs.edit().putBoolean(AlarmScheduler.KEY_ENABLED, false).apply(); AlarmScheduler.cancel(context) }) {
                                Text("Отключить")
                            }
                        }
                    }
                    Text("Будильник запускает выбранный режим по расписанию. Ручной рандом находится отдельной кнопкой выше.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            Spacer(Modifier.height(12.dp))
            SectionLabel(stringResource(R.string.vibration))
            Spacer(Modifier.height(6.dp))

            val vibModes = listOf(
                Protocol.Command.MODE1, Protocol.Command.MODE2, Protocol.Command.MODE3,
                Protocol.Command.MODE4, Protocol.Command.MODE5, Protocol.Command.MODE6,
                Protocol.Command.MODE7, Protocol.Command.MODE8, Protocol.Command.MODE9,
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                for (row in vibModes.chunked(3)) {
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        for (cmd in row) {
                            ControlButton(
                                label = cmd.byte.toString(),
                                accessibilityLabel = cmd.label(context),
                                isActive = activeCommand == cmd,
                                onClick = { send(cmd) },
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxHeight()
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Spacer(Modifier.height(12.dp))
            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SectionLabel(stringResource(R.string.heat))
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        ControlButton(
                            stringResource(R.string.heat_on_label),
                            activeCommand == Protocol.Command.HEAT_ON,
                            { send(Protocol.Command.HEAT_ON) },
                            Modifier
                                .weight(1f)
                                .height(48.dp),
                            accessibilityLabel = Protocol.Command.HEAT_ON.label(context)
                        )
                        ControlButton(
                            stringResource(R.string.heat_off_label),
                            activeCommand == Protocol.Command.HEAT_OFF,
                            { send(Protocol.Command.HEAT_OFF) },
                            Modifier
                                .weight(1f)
                                .height(48.dp),
                            accessibilityLabel = Protocol.Command.HEAT_OFF.label(context)
                        )
                    }
                }

                Column(
                    modifier = Modifier.weight(1.4f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    SectionLabel(stringResource(R.string.suction))
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        val suckCmds = listOf(
                            Protocol.Command.SUCK1, Protocol.Command.SUCK2,
                            Protocol.Command.SUCK3, Protocol.Command.SUCK4,
                            Protocol.Command.SUCK5,
                        )
                        for (cmd in suckCmds) {
                            ControlButton(
                                label = (cmd.byte - 0x50).toString(),
                                accessibilityLabel = cmd.label(context),
                                isActive = activeCommand == cmd,
                                onClick = { send(cmd) },
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                            )
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))

            if (!hasBluetoothPermission) {
                TextButton(onClick = requestPermission, modifier = Modifier.fillMaxWidth()) {
                    Text(stringResource(R.string.allow_bluetooth))
                }
            }

            Text(
                status,
                style = MaterialTheme.typography.bodySmall,
                fontFamily = FontFamily.Monospace,
                color = MaterialTheme.colorScheme.outline,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(),
                maxLines = 1
            )

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = { send(Protocol.Command.STOP) },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(stringResource(R.string.stop_device), fontWeight = FontWeight.Bold)
                }
                OutlinedButton(
                    onClick = { stop() },
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = MaterialTheme.colorScheme.error
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        stringResource(R.string.stop_broadcast),
                        fontWeight = FontWeight.Bold,
                        fontSize = 12.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun StatusChip(label: String, active: Boolean) {
    val bg by animateColorAsState(
        if (active) MaterialTheme.colorScheme.primaryContainer
        else MaterialTheme.colorScheme.surfaceVariant,
        tween(300), label = ""
    )
    val dot by animateColorAsState(
        if (active) MaterialTheme.colorScheme.primary
        else MaterialTheme.colorScheme.outline,
        tween(300), label = ""
    )

    Surface(shape = RoundedCornerShape(20.dp), color = bg) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(dot)
            )
            Text(
                label,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SectionLabel(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.labelSmall,
        color = MaterialTheme.colorScheme.primary,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.5.sp
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ControlButton(
    label: String,
    isActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    accessibilityLabel: String = label
) {
    val containerColor by animateColorAsState(
        if (isActive) MaterialTheme.colorScheme.primary
        else MaterialTheme.colorScheme.surfaceVariant,
        tween(200), label = ""
    )
    val contentColor by animateColorAsState(
        if (isActive) MaterialTheme.colorScheme.onPrimary
        else MaterialTheme.colorScheme.onSurfaceVariant,
        tween(200), label = ""
    )

    Surface(
        onClick = onClick,
        modifier = modifier.semantics {
            selected = isActive
            contentDescription = accessibilityLabel
        },
        shape = RoundedCornerShape(12.dp),
        color = containerColor,
        contentColor = contentColor
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(
                label,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}
