// SPDX-FileCopyrightText: 2026 Hirusha Adikari
// SPDX-License-Identifier: MIT
package dev.hirusha.lscontroller

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.app.Service
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import androidx.core.app.NotificationCompat

class VibrationAlarmService : Service() {
    companion object {
        const val EXTRA_DURATION = "duration_seconds"
        const val EXTRA_MODE = "alarm_mode"
        const val ACTION_STOP = "dev.hirusha.lscontroller.ALARM_STOP"
        private const val CHANNEL_ID = "vibration_alarm_channel"
        private const val NOTIFICATION_ID = 4109
    }

    private val handler = Handler(Looper.getMainLooper())
    private var ble: BleController? = null

    override fun onCreate() {
        super.onCreate()
        createChannel()
        startForeground(NOTIFICATION_ID, notification("Рандом: управление вибрацией"))
        ble = BleController(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopVibration()
            return START_NOT_STICKY
        }
        val duration = (intent?.getIntExtra(EXTRA_DURATION, 60) ?: 60).coerceIn(5, 3600)
        val mode = intent?.getIntExtra(EXTRA_MODE, 1) ?: 1
        val controller = ble ?: return START_NOT_STICKY
        handler.removeCallbacksAndMessages(null)
        startAtMode(controller, mode)
        stopAtDeadline(controller, duration * 1000L)
        return START_NOT_STICKY
    }

    private fun startAtMode(controller: BleController, mode: Int) {
        if (mode == 10) {
            // Occasionally perform a surprise burst: step through all nine modes
            // in sequence over roughly two seconds, then resume normal random mode.
            if ((1..6).random() == 1) {
                runSurpriseBurst(controller, 1)
            } else {
                val next = (1..9).filter { it != lastRandomMode }.random()
                lastRandomMode = next
                controller.startCycle(next) { status -> if (status.failed) stopSelf() }
                handler.postDelayed({ startAtMode(controller, 10) }, (5L..30L).random() * 1000L)
            }
        } else {
            controller.startCycle(mode.coerceIn(1, 9)) { status -> if (status.failed) stopSelf() }
        }
    }

    private var lastRandomMode = 0

    private fun runSurpriseBurst(controller: BleController, mode: Int) {
        if (mode > 9) {
            handler.postDelayed({ startAtMode(controller, 10) }, (5L..30L).random() * 1000L)
            return
        }
        // About 220 ms per mode = ~2 seconds for all nine. A short BLE dwell
        // helps the device receive rapid changes; actual timing depends on BLE.
        controller.startCycle(mode, dwellMs = 30L) { status -> if (status.failed) stopSelf() }
        handler.postDelayed({ runSurpriseBurst(controller, mode + 1) }, 220L)
    }

    private fun stopAtDeadline(controller: BleController, delay: Long) {
        handler.postDelayed({ stopVibration() }, delay)
    }

    private fun stopVibration() {
        handler.removeCallbacksAndMessages(null)
        val controller = ble ?: run { stopSelf(); return }
        controller.stopAll()
        controller.startCycle(Protocol.Command.STOP.byte) { }
        handler.postDelayed({ stopSelf() }, 1800)
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        ble?.close()
        ble = null
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(CHANNEL_ID, "Будильник вибрации", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun notification(message: String): Notification {
        val stopIntent = Intent(this, VibrationAlarmService::class.java).setAction(ACTION_STOP)
        val stopPending = PendingIntent.getService(
            this, 4110, stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("Рандом")
            .setContentText(message)
            .addAction(0, "Стоп", stopPending)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .build()
    }
}
