// SPDX-FileCopyrightText: 2026 Hirusha Adikari
// SPDX-License-Identifier: MIT
package dev.hirusha.lscontroller

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.content.ContextCompat
import java.util.Calendar

object AlarmScheduler {
    private const val PREFS = "vibration_alarm"
    const val KEY_ENABLED = "enabled"
    const val KEY_HOUR = "hour"
    const val KEY_MINUTE = "minute"
    const val KEY_DURATION = "duration_seconds"

    fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun scheduleNext(context: Context) {
        val p = prefs(context)
        if (!p.getBoolean(KEY_ENABLED, false)) return
        val hour = p.getInt(KEY_HOUR, 7)
        val minute = p.getInt(KEY_MINUTE, 0)
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) add(Calendar.DAY_OF_YEAR, 1)
        }
        val alarmIntent = PendingIntent.getBroadcast(
            context, 4107, Intent(context, VibrationAlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val showIntent = PendingIntent.getActivity(
            context, 4108, Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val manager = context.getSystemService(AlarmManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && !manager.canScheduleExactAlarms()) return
        manager.setAlarmClock(AlarmManager.AlarmClockInfo(cal.timeInMillis, showIntent), alarmIntent)
    }

    fun cancel(context: Context) {
        val intent = PendingIntent.getBroadcast(
            context, 4107, Intent(context, VibrationAlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        context.getSystemService(AlarmManager::class.java).cancel(intent)
    }
}

class VibrationAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val prefs = AlarmScheduler.prefs(context)
        if (!prefs.getBoolean(AlarmScheduler.KEY_ENABLED, false)) return
        // Schedule tomorrow's occurrence before starting the vibration service.
        AlarmScheduler.scheduleNext(context)
        val service = Intent(context, VibrationAlarmService::class.java).apply {
            putExtra(VibrationAlarmService.EXTRA_DURATION, prefs.getInt(AlarmScheduler.KEY_DURATION, 60))
        }
        try {
            ContextCompat.startForegroundService(context, service)
        } catch (_: Exception) {
            // Android may block background starts in unusual device states; the next daily alarm remains scheduled.
        }
    }
}
